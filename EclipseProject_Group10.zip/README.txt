This is the zipped Eclipse project for Assignment 2 of Group 10 containing
the following members:
Aidan Lee
Aminah Farzana
Jeffrey Rude
Nargiz Rzayeva

The test suite java file (testsuite.java) located in the package 
org.jfree.data.testsuite is the single file that will run all the JUnit 
tests created. These tests are located in the java class files in the 
org.jfree.data.test package, where tests are separated into classes based
on the method being tested (see comments).

