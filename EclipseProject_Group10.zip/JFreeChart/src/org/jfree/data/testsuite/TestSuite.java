package org.jfree.data.testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({

// Testing Methods in class org.jfree.data.Range 
	
	// Test Method 1 boolean contains(double value) 
	org.jfree.data.test.RangeTestContain.class,
	  
	// Test Method 2 double getLength() 
	org.jfree.data.test.RangeLengthTest.class,
	  
	// Test Methods 3 double getLowerBound() and 4 double getUpperBound() 
	org.jfree.data.test.RangeBoundsTests.class,
	  
	// Test Method 5 boolean intersects(double lower, double upper) 
	org.jfree.data.test.RangeTestIntersect.class,
	
// Testing Methods in class org.jfree.data.DataUtilities	
	
	// Test Method 1 static double calculateColumnTotal(Values2D data, int column) 
	org.jfree.data.test.DataUtilities_calculateColumnTotal.class,
	  
	// Test Method 2 static double calculateRowTotal(Values2D data, int row) 
	org.jfree.data.test.DataUtilities_calculateRowTotal.class,
	  
	// Test Methods 3 static java.lang.Number[] createNumberArray(double[] data) 
	org.jfree.data.test.DataUtilitiesCreateNumberArrayTest.class,
	  
	// Test Method 4 static java.lang.Number[][] createNumberArray2D(double[][] data) 
	org.jfree.data.test.DataUtilitiesCreateNumberArray2DTest.class,
	  
	// Test Method 5 static KeyedValues getCumulativePercentages(KeyedValues data) 
	org.jfree.data.test.DataUtilitiesGetCumulativePercentagesTestOne.class

})

public class TestSuite {

}
