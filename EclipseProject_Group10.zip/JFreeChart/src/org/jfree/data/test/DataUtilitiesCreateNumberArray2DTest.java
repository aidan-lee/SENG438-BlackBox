package org.jfree.data.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.security.InvalidParameterException;

import org.jfree.data.DataUtilities;
import org.junit.Assert;
import org.junit.Test;

//X: size of outer array
//Y: size of inner arrays
//Z: value in an element of the array

/**
 * Testing method static java.lang.Number[][] createNumberArray2D(double[][] data) 
 * in class org.jfree.data.DataUtilities
 *
 */
public class DataUtilitiesCreateNumberArray2DTest extends DataUtilities
{
	private double[][] nullArray;
	private double[][] x0y0Array = new double[0][0];
	private double[][] x1y0Array = new double[1][0];
	private double[][] x7y0Array = new double[7][0];
	private double[][] x0y1Array = new double[0][1];
	private double[][] x0y5Array = new double[0][5];
	private double[][] x1y1NegzArray = {{-42}};
	private double[][] x3y1InfAndZeroArray = {{Double.POSITIVE_INFINITY}, {Double.NEGATIVE_INFINITY}, {0}};
	private double[][] x1y3PosAndMinArray = {{42, Double.MIN_VALUE, Double.MIN_VALUE + 1}};
	private double[][] x2y2MaxAndNaNArray = {{Double.MAX_VALUE, Double.MAX_VALUE - 1}, {Double.NaN, 4242}};
	//Boundary value testing/Weak Robustness testing
	//Variables
	//Outer array length (X):
	//0 <= X < ?, X != null, NAN
	//Test Cases:
	//X = null - 
	//X < 0 - This is not testable, as you cannot initialize an array with negative length
	//X = 0 - X_LB
	//X = 1 - X_ALB
	//1 < X < ? - X_NOM
	//X > ? - This is not testable, as we don't know what the max size of an array is (it's probably system dependent, and less than Double.MAX_VALUE)
	
	//Inner Array Length (Y):
	//0 <= Y < ?, Y != null, NAN
	//Test Cases:
	//Y = null - 
	//Y < 0 - This is not testable, as you cannot initialize an array with negative length
	//Y = 0 - Y_LB
	//Y = 1 - Y_ALB
	//1 < Y < ? - LNOM
	//Y > ? - This is not testable, as we don't know what the max size of an array is (it's probably system dependent, and less than Double.MAX_VALUE)
	
	//Values in the array (V):
	//-infinity < V < +infinity, V != null
	//V = Double,MIN_VALUE - 1 - Not testable. Double.MIN_VALUE - 1 = Double.MIN_VALUE due to rounding
	//V = Double.MIN_VALUE - V_LB
	//V = Double.MIN_VALUE + 1 - V_ALB
	//V < 0 - V_NOM
	//V = 0 - V_NOM
	//V > 0 - V_NOM
	//V = Double.MAX_VALUE - 1 - V_BUB
	//V = Double.MAX_VALUE - V_UB
	//V = Double.MAX_VALUE + 1 - Not testable. Double.MAX_VALUE + 1 = Double.MAX_VALUE due to rounding
	//V = Double.NEGATIVE_INFINITY
	//V = Double.POSITIVE_INFINITY
	//V = Double.NaN
	//V = null
//Tests-----------------------------------------------------------------------------------
	@Test//(expected = InvalidParameterException.class)
	public void test_createNumberArray2D_NullArray()
	{
		try
		{
			DataUtilities.createNumberArray2D(nullArray);
		}
		catch(InvalidParameterException e)
		{
			assertTrue(true);
		}
		catch(Exception e)
		{
			fail("createNumberArray2D did not throw an InvalidParameterException when given a null argument.");
		}
	}
	
	@Test
	public void test_createNumberArray2D_X_LB_Y_LB()
	{
		Number[][] x = new Number[0][0];
		Assert.assertArrayEquals("createNumberArray2D could not create a 0x0 array properly. (case = X_LB, Y_LB)", x, x0y0Array);
	}
	
	@Test
	public void test_createNumberArray2D_X_ALB_Y_LB()
	{
		Number[][] x = new Number[1][0];
		Assert.assertArrayEquals("createNumberArray2D could not create a 1x0 array properly. (case = X_ALB, Y_LB)", x, x1y0Array);
	}
	
	@Test
	public void test_createNumberArray2D_X_NOM_Y_LB()
	{
		Number[][] x = new Number[7][0];
		Assert.assertArrayEquals("createNumberArray2D could not create a 7x0 array properly. (case = X_NOM, Y_LB)", x, x7y0Array);
	}
	
	@Test
	public void test_createNumberArray2D_X_LB_Y_ALB()
	{
		Number[][] x = new Number[0][1];
		Assert.assertArrayEquals("createNumberArray2D could not create a 0x1 array properly. (case = X_LB, Y_ALB)", x, x0y1Array);
	}
	
	@Test
	public void test_createNumberArray2D_X_LB_Y_NOM()
	{
		Number[][] x = new Number[0][5];
		Assert.assertArrayEquals("createNumberArray2D could not create a 0x5 array properly. (case = X_LB, Y_NOM)", x, x0y5Array);
	}
	
	@Test
	public void test_createNumberArray2D_X_ALB_Y_ALB_V_NOM()
	{
		Number[][] x = {{-42.0}};
		Assert.assertArrayEquals("createNumberArray2D could not create a 1x1 = {{-42.0}} array properly. (case = X_ALB, Y_ALB, V_NOM)", x, x1y1NegzArray);
	}
	
	@Test
	public void test_createNumberArray2D_X_NOM_Y_ALB_V_POSINF_V_NEGINF_V_NOM()
	{
		Number[][] x = {{Double.POSITIVE_INFINITY}, {Double.NEGATIVE_INFINITY}, {0.0}};
		Assert.assertArrayEquals("createNumberArray2D could not create a 3x1 = {{Double.POSITIVE_INFINITY}, {Double.NEGATIVE_INFINITY}, {0.0}} array properly. (case = X_NOM, Y_ALB, V_NOM, V_POSINF, V_NEGINF)", x, x3y1InfAndZeroArray);
	}
	
	@Test
	public void test_createNumberArray2D_X_ABL_Y_NOM_V_NOM_V_LB_V_ALB()
	{
		Number[][] x = {{42.0, Double.MIN_VALUE, Double.MIN_VALUE + 1}};
		Assert.assertArrayEquals("createNumberArray2D could not create a 1x3 = {{42.0, Double.MIN_VALUE, Double.MIN_VALUE + 1}} array properly. (case = X_ALB, Y_NOM, V_NOM, V_LB, V_ALB)", x, x1y3PosAndMinArray);
	}
	
	@Test
	public void test_createNumberArray2D_X_NOM_Y_NOM_V_NOM_V_UB_V_BUB_V_NAN()
	{
		Number[][] x = {{Double.MAX_VALUE, Double.MAX_VALUE - 1}, {Double.NaN, 4242.0}};
		Assert.assertArrayEquals("createNumberArray2D could not create a 2x2 = {{Double.MAX_VALUE, Double.MAX_VALUE - 1}, {Double.NaN, 4242.0}} array properly. (case = X_NOM, Y_NOM, V_NOM, V_UB, V_BUB, V_NAN)", x, x2y2MaxAndNaNArray);
	}
	
	
	
//----------------------------------------------------------------------------------------
}
