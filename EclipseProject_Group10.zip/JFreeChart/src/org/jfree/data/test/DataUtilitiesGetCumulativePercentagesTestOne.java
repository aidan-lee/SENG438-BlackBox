package org.jfree.data.test;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;
import java.util.ArrayList;

import org.jfree.data.DataUtilities;
import org.jfree.data.KeyedValues;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Testing method static KeyedValues getCumulativePercentages(KeyedValues data)  
 * in class org.jfree.data.DataUtilities
 *
 */
public class DataUtilitiesGetCumulativePercentagesTestOne extends DataUtilities
{	
	//Boundary Value Testing/Weak Robustness Testing
	//Variables:
	//Values in the KeyedValues mockery (V)
	// -inf < V < +inf
	//Test Cases:
	//V = Double.MIN_VALUE - V_LB
	//V = Double.MAX_VALUE - V_UB
	//V = Double.POSITIVE_INFINITY - V_POSINF
	//V = Double.NEGATIVE_INFINITY - V_NEGINF
	//V = Double.NaN - V_NAN
	//V < 0 - V_NOM
	//V = 0 - V_NOM
	//V > 0 - V_NOM
	KeyedValues Object1TestResult;
	ArrayList<Integer> Object1TestKeyArray;
	
	KeyedValues Object2TestResult;
	ArrayList<Integer> Object2TestKeyArray;
	
	KeyedValues Object3TestResult;
	ArrayList<Integer> Object3TestKeyArray;
	KeyedValues MockedObject3;
	
	KeyedValues Object4TestResult;
	ArrayList<Integer> Object4TestKeyArray;
	KeyedValues MockedObject4;
	
	@Before
	public void setUp() throws Exception
	{		
		//Test Object 1
		//Input
		//K|V
		//0|5
		//1|9
		//2|2
		//
		//Expected Output
		//K|V
		//0|0.3125
		//1|0.875
		//2|1.0
		Object1TestKeyArray = new ArrayList<>();
		Object1TestKeyArray.add(0);
		Object1TestKeyArray.add(1);
		Object1TestKeyArray.add(2);
		
		Mockery Object1Mockery = new Mockery();
		final KeyedValues MockedObject1 = Object1Mockery.mock(KeyedValues.class);
		Object1Mockery.checking(new Expectations()
		{
			{
				allowing(MockedObject1).getItemCount();
				will(returnValue(3));			
				
				allowing(MockedObject1).getIndex(0);
				will(returnValue(0));
				allowing(MockedObject1).getIndex(1);
				will(returnValue(1));
				allowing(MockedObject1).getIndex(2);
				will(returnValue(2));
				
				allowing(MockedObject1).getKey(0);
				will(returnValue(0));
				allowing(MockedObject1).getKey(1);
				will(returnValue(1));
				allowing(MockedObject1).getKey(2);
				will(returnValue(2));
				
				allowing(MockedObject1).getKeys();
				will(returnValue(Object1TestKeyArray));
				
				allowing(MockedObject1).getValue(0);
				will(returnValue(5));
				allowing(MockedObject1).getValue(1);
				will(returnValue(9));
				allowing(MockedObject1).getValue(2);
				will(returnValue(2));
			}
		});
		Object1TestResult = DataUtilities.getCumulativePercentages(MockedObject1);
		
		//Test Object 2
		//Input
		//K|V
		//0|0
		//1|-3
		//2|5
		//3|9
		//4|-42
		//
		//Expected Output
		//K|V
		//0|0
		//1|-3/-31
		//2|2/-31
		//3|11/-31
		//4|-31/-31
		Object2TestKeyArray = new ArrayList<>();
		Object2TestKeyArray.add(0);
		Object2TestKeyArray.add(1);
		Object2TestKeyArray.add(2);
		Object2TestKeyArray.add(3);
		Object2TestKeyArray.add(4);
		
		Mockery Object2Mockery = new Mockery();
		final KeyedValues MockedObject2 = Object2Mockery.mock(KeyedValues.class);
		Object2Mockery.checking(new Expectations()
		{
			{
				allowing(MockedObject2).getItemCount();
				will(returnValue(5));			
				
				allowing(MockedObject2).getIndex(0);
				will(returnValue(0));
				allowing(MockedObject2).getIndex(1);
				will(returnValue(1));
				allowing(MockedObject2).getIndex(2);
				will(returnValue(2));
				allowing(MockedObject2).getIndex(3);
				will(returnValue(3));
				allowing(MockedObject2).getIndex(4);
				will(returnValue(4));
				
				allowing(MockedObject2).getKey(0);
				will(returnValue(0));
				allowing(MockedObject2).getKey(1);
				will(returnValue(1));
				allowing(MockedObject2).getKey(2);
				will(returnValue(2));
				allowing(MockedObject2).getKey(3);
				will(returnValue(3));
				allowing(MockedObject2).getKey(4);
				will(returnValue(4));

				
				allowing(MockedObject2).getKeys();
				will(returnValue(Object2TestKeyArray));
				
				allowing(MockedObject2).getValue(0);
				will(returnValue(0));
				allowing(MockedObject2).getValue(1);
				will(returnValue(-3));
				allowing(MockedObject2).getValue(2);
				will(returnValue(5));
				allowing(MockedObject2).getValue(3);
				will(returnValue(9));
				allowing(MockedObject2).getValue(4);
				will(returnValue(-42));
			}
		});
		Object2TestResult = DataUtilities.getCumulativePercentages(MockedObject2);
		
		//Test Object 3
		//Input
		//K|V
		//0|5
		//1|-5
		//
		//Expected Output
		//Exception
		Object3TestKeyArray = new ArrayList<>();
		Object3TestKeyArray.add(0);
		Object3TestKeyArray.add(1);
		
		Mockery Object3Mockery = new Mockery();
		MockedObject3 = Object3Mockery.mock(KeyedValues.class);
		Object3Mockery.checking(new Expectations()
		{
			{
				allowing(MockedObject3).getItemCount();
				will(returnValue(2));			
				
				allowing(MockedObject3).getIndex(0);
				will(returnValue(0));
				allowing(MockedObject3).getIndex(1);
				will(returnValue(1));
				
				allowing(MockedObject3).getKey(0);
				will(returnValue(0));
				allowing(MockedObject3).getKey(1);
				will(returnValue(1));
				
				allowing(MockedObject3).getKeys();
				will(returnValue(Object3TestKeyArray));
				
				allowing(MockedObject3).getValue(0);
				will(returnValue(5));
				allowing(MockedObject3).getValue(1);
				will(returnValue(-5));
			}
		});
		
		//Test Object 3
		//Input
		//K|V
		//0|max
		//1|min
		//2|NaN
		//3|+inf
		//4|-inf
		//
		//Expected Output
		//Exception
		Object4TestKeyArray = new ArrayList<>();
		Object4TestKeyArray.add(0);
		Object4TestKeyArray.add(1);
		Object4TestKeyArray.add(2);
		Object4TestKeyArray.add(3);
		Object4TestKeyArray.add(4);
		
		Mockery Object4Mockery = new Mockery();
		MockedObject4 = Object4Mockery.mock(KeyedValues.class);
		Object4Mockery.checking(new Expectations()
		{
			{
				allowing(MockedObject4).getItemCount();
				will(returnValue(5));			
				
				allowing(MockedObject4).getIndex(0);
				will(returnValue(0));
				allowing(MockedObject4).getIndex(1);
				will(returnValue(1));
				allowing(MockedObject4).getIndex(2);
				will(returnValue(2));
				allowing(MockedObject4).getIndex(3);
				will(returnValue(3));
				allowing(MockedObject4).getIndex(4);
				will(returnValue(4));
				
				allowing(MockedObject4).getKey(0);
				will(returnValue(0));
				allowing(MockedObject4).getKey(1);
				will(returnValue(1));
				allowing(MockedObject4).getKey(2);
				will(returnValue(2));
				allowing(MockedObject4).getKey(3);
				will(returnValue(3));
				allowing(MockedObject4).getKey(4);
				will(returnValue(4));
				
				allowing(MockedObject4).getKeys();
				will(returnValue(Object4TestKeyArray));
				
				allowing(MockedObject4).getValue(0);
				will(returnValue(Double.MAX_VALUE));
				allowing(MockedObject4).getValue(1);
				will(returnValue(Double.MIN_VALUE));
				allowing(MockedObject4).getValue(2);
				will(returnValue(Double.NaN));
				allowing(MockedObject4).getValue(3);
				will(returnValue(Double.POSITIVE_INFINITY));
				allowing(MockedObject4).getValue(4);
				will(returnValue(Double.NEGATIVE_INFINITY));
			}
		});
		
	}
	//Generic Tests
	@Test//(expected = InvalidParameterException.class)
	public void test_getCumulativePercentages_NullInput()
	{
		try
		{
			DataUtilities.getCumulativePercentages(null);
			fail("getCumulativePercentages did not throw an InvalidParameterException when given a null argument.");
		}
		catch(InvalidParameterException e)
		{
			assertTrue(true);
		}
		catch(Exception e)
		{
			fail("getCumulativePercentages did not throw an InvalidParameterException when given a null argument.");
		}
	}
	
	//Tests for Object 1
	@Test
	public void test_getCumulativePercentages_Object1GetIndex0()
	{
		assertEquals("getCumulativePercentages Object 1 GetIndex(0)", 0, Object1TestResult.getIndex(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetIndex1()
	{
		assertEquals("getCumulativePercentages Object 1 GetIndex(1)", 1, Object1TestResult.getIndex(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetIndex2()
	{
		assertEquals("getCumulativePercentages Object 1 GetIndex(2)", 2, Object1TestResult.getIndex(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetKey0()
	{
		assertEquals("getCumulativePercentages Object 1 getKey(0)", 0, Object1TestResult.getKey(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetKey1()
	{
		assertEquals("getCumulativePercentages Object 1 getKey(1)", 1, Object1TestResult.getKey(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetKey2()
	{
		assertEquals("getCumulativePercentages getKey(2)", 2, Object1TestResult.getKey(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetValue0()
	{
		assertEquals("getCumulativePercentages Object 1 getValue(0)", 0.3125, Object1TestResult.getValue(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetValue1()
	{
		assertEquals("getCumulativePercentages Object 1 getValue(1)", 0.875, Object1TestResult.getValue(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetValue2()
	{
		assertEquals("getCumulativePercentages Object 1 getValue(2)", 1.0, Object1TestResult.getValue(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object1GetKeys()
	{
		Assert.assertArrayEquals("getCumulativePercentages Object 1 getKeys()", Object1TestKeyArray.toArray(), Object1TestResult.getKeys().toArray());
	}
	
	//Tests for Object 2
	@Test
	public void test_getCumulativePercentages_Object2GetIndex0()
	{
		assertEquals("getCumulativePercentages Object 2 GetIndex(0)", 0, Object2TestResult.getIndex(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetIndex1()
	{
		assertEquals("getCumulativePercentages Object 2 GetIndex(1)", 1, Object2TestResult.getIndex(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetIndex2()
	{
		assertEquals("getCumulativePercentages Object 2 GetIndex(2)", 2, Object2TestResult.getIndex(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetIndex3()
	{
		assertEquals("getCumulativePercentages Object 2 GetIndex(3)", 3, Object2TestResult.getIndex(3));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetIndex4()
	{
		assertEquals("getCumulativePercentages Object 2 GetIndex(4)", 4, Object2TestResult.getIndex(4));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetKey0()
	{
		assertEquals("getCumulativePercentages Object 2 getKey(0)", 0, Object2TestResult.getKey(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetKey1()
	{
		assertEquals("getCumulativePercentages Object 2 getKey(1)", 1, Object2TestResult.getKey(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetKey2()
	{
		assertEquals("getCumulativePercentages Object 2 getKey(2)", 2, Object2TestResult.getKey(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetKey3()
	{
		assertEquals("getCumulativePercentages Object 2 getKey(3)", 3, Object2TestResult.getKey(3));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetKey4()
	{
		assertEquals("getCumulativePercentages Object 2 getKey(4)", 4, Object2TestResult.getKey(4));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetValue0()
	{
		assertEquals("getCumulativePercentages Object 2 getValue(0)", 0, Object2TestResult.getValue(0));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetValue1()
	{
		assertEquals("getCumulativePercentages Object 2 getValue(1)", ((double) -3/ (double) -31), Object2TestResult.getValue(1));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetValue2()
	{
		assertEquals("getCumulativePercentages Object 2 getValue(2)", ((double) 2/ (double) -31), Object2TestResult.getValue(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetValue3()
	{
		assertEquals("getCumulativePercentages Object 2 getValue(3)", ((double) 11/ (double) -31), Object2TestResult.getValue(2));
	}
	
	@Test
	public void test_getCumulativePercentages_Object2GetValue4()
	{
		assertEquals("getCumulativePercentages Object 2 getValue(4)", 1.0, Object2TestResult.getValue(2));
	}

	@Test
	public void test_getCumulativePercentages_Object2GetKeys()
	{
		Assert.assertArrayEquals("getCumulativePercentages Object 2 getKeys()", Object2TestKeyArray.toArray(), Object2TestResult.getKeys().toArray());
	}
	
	//Tests for Object 3
	@Test//(expected = IllegalArgumentException.class)
	public void test_getCumulativePercentages_Object3DivideByZero()
	{
		try
		{
			Object3TestResult = DataUtilities.getCumulativePercentages(MockedObject3); //Object 3 should cause division by zero, as the two values are 5 and -5, which sum to zero
			fail("getCumulativePercentages did not throw an IllegalArgumentException when given parameters that should cause division by zero");

		}
		catch(Exception e)
		{
			assertTrue(true);

		}
	}

	//Tests for Object 4
	@Test//(expected = IllegalArgumentException.class)
	public void test_getCumulativePercentages_Object4BadNumbers()
	{
		try
		{
			Object4TestResult = DataUtilities.getCumulativePercentages(MockedObject4); //Object 4 should cause an exception, since you can't perform arithmetic on min/max/NaN/PosInf/NegInf
			fail("getCumulativePercentages did not throw an InvalidParameterException when given input that does not make sense (+/- inf, max/min, NaN)");
		}
		catch(Exception e)
		{
			assertTrue(true);
		}
	}
}

