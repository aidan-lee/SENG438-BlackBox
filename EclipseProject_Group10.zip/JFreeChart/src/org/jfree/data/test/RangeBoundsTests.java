package org.jfree.data.test;
import static org.junit.Assert.*;
import org.jfree.data.Range;
import org.junit.*;

/**
 * Testing methods double getLowerBound() and double getUpperBound()   
 * in class org.jfree.data.Range 
 *
 */
public class RangeBoundsTests {
	private Range nullRange;
	private Range minPlusOneRange;
	private Range minRange;
	private Range minMinusOneRange;
	private Range maxPlusOneRange;
	private Range maxRange;
	private Range maxMinusOneRange;
	private Range minMaxRange;
	private Range maxMinRange;
	private Range nominalRange;
	private Range nanRange;
	private Range nan0Range;
	private Range zeroNanRange;
	private Range negInfRange;
	private Range posInfRange;
	private Range posInf0Range;
	private Range zeroPosInfRange;
	private Range negInf0Range;
	private Range zeroNegInfRange;
	
	@BeforeClass 
	public static void setUpBeforeClass() throws Exception {
		
	}
	@Before
	public void setUp() throws Exception {
		nullRange = null;
		minPlusOneRange = new Range(-Double.MAX_VALUE + 1, -Double.MAX_VALUE + 1);
		minRange = new Range(-Double.MAX_VALUE, -Double.MAX_VALUE);
		minMinusOneRange = new Range(-Double.MAX_VALUE - 1, -Double.MAX_VALUE - 1);
		
		maxPlusOneRange = new Range(Double.MAX_VALUE + 1, Double.MAX_VALUE + 1);
		maxRange = new Range(Double.MAX_VALUE, Double.MAX_VALUE);
		maxMinusOneRange = new Range(Double.MAX_VALUE - 1, Double.MAX_VALUE - 1);
		
		minMaxRange = new Range(-Double.MAX_VALUE, Double.MAX_VALUE);
		//maxMinRange = new Range(Double.MAX_VALUE, -Double.MAX_VALUE);
		
		nominalRange = new Range(0, 0);
		
		nanRange = new Range(Double.NaN, Double.NaN);
		nan0Range = new Range(Double.NaN, 0);
		zeroNanRange = new Range(0, Double.NaN);
		
		negInfRange = new Range(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
		posInfRange = new Range(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
		
		//posInf0Range = new Range(Double.POSITIVE_INFINITY, 0);
		zeroPosInfRange = new Range(0, Double.POSITIVE_INFINITY);
		negInf0Range = new Range(Double.NEGATIVE_INFINITY, 0);
		//zeroNegInfRange = new Range(0, Double.NEGATIVE_INFINITY);
	}
	
	//TODO: Tests for getLowerBound()

	//Tests the function getLowerBound() in the Range class
	//This test is part of the test suite but cannot be executed.  Causes a null pointer error.
	//Tests equivalence class 1
	@Ignore
	public void getLowerBound_NullRange_Null() 
	{
		assertNull("The lower bound of a null range should be null", nullRange.getLowerBound());
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 12
	//Tests boundary condition lower bound = -Double.MAX_VALUE
	@Test
	public void getLowerBound_minPlusOneRange_MinPlusOne() 
	{
		assertEquals("The lower bound of the range (min+1, min+1) should be min+1", -Double.MAX_VALUE + 1, minPlusOneRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 11
	//Tests boundary condition lower bound = -Double.MAX_VALUE
	@Test
	public void getLowerBound_minRange_0()
	{
		assertEquals("The lower bound of the range (min, min) should be min", -Double.MAX_VALUE, minRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2
	//Tests boundary condition lower bound = -Double.MAX_VALUE
	@Test
	public void getLowerBound_minMinusOneRange_MinMinusOne() 
	{
		assertEquals("The lower bound of the range (min-1, min-1) should be min-1", -Double.MAX_VALUE - 1, minMinusOneRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 9
	//Tests boundary condition lower bound = Double.MAX_VALUE
	@Test
	public void getLowerBound_maxPlusOneRange_MaxPlusOne() 
	{
		assertEquals("The lower bound of the range (max+1, max+1) should be max+1", Double.MAX_VALUE + 1, maxPlusOneRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 8
	//Tests boundary condition lower bound = Double.MAX_VALUE
	@Test
	public void getLowerBound_maxRange_0()
	{
		assertEquals("The lower bound of the range (max, max) should be max", Double.MAX_VALUE, maxRange.getLowerBound(), 0.000000001d);
	} 
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 12
	//Tests boundary condition lower bound = Double.MAX_VALUE
	@Test
	public void getLowerBound_maxMinusOneRange_MaxMinusOne() 
	{
		assertEquals("The lower bound of the range (max-1, max-1) should be max-1", Double.MAX_VALUE - 1, maxMinusOneRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 5, 11
	//Tests boundary condition lower bound = -Double.MAX_VALUE
	@Test
	public void getLowerBound_minMaxRange_Min() 
	{
		assertEquals("The lower bound of the range (min, max) should be min", -Double.MAX_VALUE, minMaxRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Testing range (max, min) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 4, 8
	//Test boundary condition lower bound = -Double.MAX_VALUE
	@Ignore
	public void getLowerBound_maxMinRange_Min() 
	{
		maxMinRange = new Range(Double.MAX_VALUE, Double.MIN_VALUE);
		assertEquals("The lower bound of the range (max, min) should be min", Double.MIN_VALUE, maxMinRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 12
	//Lower bound = Nominal
	@Test
	public void getLowerBound_nominalRange_0()
	{
		assertEquals("The lower bound of the range (0, 0) should be 0", 0, nominalRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 2, 13
	//Tests boundary condition lower bound = Double.NaN
	@Test
	public void getLowerBound_nanRange_NaN()
	{
		assertEquals("The lower bound of the range (NaN, NaN) should be NaN", Double.NaN, nanRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 13
	//Tests boundary condition lower bound =  Double.NaN
	@Test
	public void getLowerBound_nan0Range_NaN()
	{
		assertEquals("The lower bound of the range (NaN, 0) should be NaN", Double.NaN, nan0Range.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 12
	//Tests boundary condition lower bound = Nominal
	@Test
	public void getLowerBound_zeroNanRange_0()
	{
		assertEquals("The lower bound of the range (0, NaN)", 0, zeroNanRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 3, 14
	//Tests boundary condition lower bound = Double.NEGATIVE_INFINITY
	@Test
	public void getLowerBound_negInfRange_negInf()
	{
		assertEquals("The lower bound of the range (NEGATIVE_INFINITY, NEGATIVE_INFINITY) should be negative infinity", Double.NEGATIVE_INFINITY, negInfRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 3, 15
	//Tests boundary condition lower bound = Double.POSITIVE_INFINITY
	@Test
	public void getLowerBound_posInfRange_posInf()
	{
		assertEquals("The lower bound of the range (POSITIVE_INFINITY, POSITIVE_INFINITY) should be positive infinity", Double.POSITIVE_INFINITY, posInfRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Testing range (Double.POSITIVE_INFINITY, 0) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 6, 15
	//Tests boundary condition lower bound = Double.POSITIVE_INFINITY
	@Ignore
	public void getLowerBound_posInf0Range_posInf()
	{
		assertEquals("The lower bound of the range (POSITIVE_INFINITY, 0) should be 0", 0, posInf0Range.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Testing equivalence class 6, 12
	//Tests boundary condition lower bound = Nominal
	@Test
	public void getLowerBound_zeroPosInfRange_0()
	{
		assertEquals("The lower bound of the range (0, POSITIVE_INFINITY) should be 0", 0, zeroPosInfRange.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Tests equivalence class 7, 14
	//Tests boundary condition lower bound Double.NEGATIVE_INFINITY
	@Test
	public void getLowerBound_negInf0Range_negInf()
	{
		assertEquals("The lower bound of the range (NEGATIVE_INFINITY, 0) should be negative infinity", Double.NEGATIVE_INFINITY, negInf0Range.getLowerBound(), 0.000000001d);
	}
	
	//Tests the function getLowerBound() in the Range class
	//Testing range (0, NEGATIVE_INFINITY) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 19
	//Tests boundary condition lower bound = Nominal
	@Ignore 
	public void getLowerBound_zeroNegInfRange_0()
	{
		assertEquals("The lower bound of the range (0, NEGATIVE_INFINITY) should be negative infinity", Double.NEGATIVE_INFINITY, zeroNegInfRange.getLowerBound(), 0.000000001d);
	}
	
	//TODO: Tests for getUpperBound()
	
	//Tests the function getUpperBound() in the Range class
	//This test is part of the test suite but cannot be executed.  Causes a null pointer error.
	//Tests equivalence class 1, where the range is null.
	@Ignore
	public void getUpperBound_NullRange_Null() 
	{
		assertNull("The lower bound of a null range should be null", nullRange.getUpperBound());
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 10
	//Tests boundary condition upper bound = -Double.MAX_VALUE
	@Test
	public void getUpperBound_minPlusOneRange_MinPlusOne() 
	{
		assertEquals("The upper bound of the range (min+1, min+1) should be min+1", -Double.MAX_VALUE + 1, minPlusOneRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 8
	//Tests boundary condition upper bound = -Double.MAX_VALUE
	@Test
	public void getUpperBound_minRange_Min()
	{
		assertEquals("The upper bound of the range (min, min) should be min", -Double.MAX_VALUE, minRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 9
	//Tests boundary condition upper bound = -Double.MAX_VALUE
	@Test
	public void getUpperBound_minMinusOneRange_MinMinusOne() 
	{
		assertEquals("The upper bound of the range (min-1, min-1) should be min-1", -Double.MAX_VALUE - 1, minMinusOneRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 7
	//Tests boundary condition upper bound = Double.MAX_VALUE
	@Test
	public void getUpperBound_maxPlusOneRange_MaxPlusOne() 
	{
		assertEquals("The upper bound of the range (max+1, max+1) should be max+1", Double.MAX_VALUE + 1, maxPlusOneRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 6
	//Tests boundary condition upper bound = Double.MAX_VALUE
	@Test
	public void getUpperBound_maxRange_Max()
	{
		assertEquals("The upper bound of the range (max, max) should be max", Double.MAX_VALUE, maxRange.getUpperBound(), 0.000000001d);
	} 
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 10
	//Tests boundary condition upper bound = Double.MAX_VALUE
	@Test
	public void getUpperBound_maxMinusOneRange_MaxMinusOne() 
	{
		assertEquals("The upper bound of the range (max-1, max-1) should be max-1", Double.MAX_VALUE - 1, maxMinusOneRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 5, 6
	//Tests boundary condition upper bound = -Double.MAX_VALUE
	@Test
	public void getUpperBound_minMaxRange_Max() 
	{
		assertEquals("The upper bound of the range (min, max) should be max", Double.MAX_VALUE, minMaxRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Testing range (max, min) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 4, 8
	//Test boundary condition upper bound = -Double.MAX_VALUE
	@Ignore
	public void getUpperBound_maxMinRange_Max() 
	{
		assertEquals("The upper bound of the range (max, min) should be max", Double.MAX_VALUE, maxMinRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 10
	//Upper bound = Nominal
	@Test
	public void getUpperBound_nominalRange_0()
	{
		assertEquals("The upper bound of the range (0, 0) should be 0", 0, nominalRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 2, 12
	//Tests boundary condition upper bound = Double.NaN
	@Test
	public void getUpperBound_nanRange_NaN()
	{
		assertEquals("The upper bound of the range (NaN, NaN) should be NaN", Double.NaN, nanRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 10
	//Tests boundary condition upper bound = Nominal
	@Test
	public void getUpperBound_nan0Range_NaN()
	{
		assertEquals("The upper bound of the range (NaN, 0) should be NaN", Double.NaN, nan0Range.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 12
	//Tests boundary condition upper bound = Double.NaN
	@Test
	public void getUpperBound_zeroNanRange_NaN()
	{
		assertEquals("The upper bound of the range (0, NaN)", 0, zeroNanRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 3, 13
	//Tests boundary condition upper bound = Double.NEGATIVE_INFINITY
	@Test
	public void getUpperBound_negInfRange_negInf()
	{
		assertEquals("The upper bound of the range (NEGATIVE_INFINITY, NEGATIVE_INFINITY) should be negative infinity", Double.NEGATIVE_INFINITY, negInfRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Tests equivalence class 3, 14
	//Tests boundary condition upper bound = Double.POSITIVE_INFINITY
	@Test
	public void getUpperBound_posInfRange_posInf()
	{
		assertEquals("The upper bound of the range (POSITIVE_INFINITY, POSITIVE_INFINITY) should be positive infinity", Double.POSITIVE_INFINITY, posInfRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Testing range (Double.POSITIVE_INFINITY, 0) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 11
	//Tests boundary condition upper bound = Nominal
	@Ignore
	public void getUpperBound_posInf0Range_0()
	{
		assertEquals("The upper bound of the range (POSITIVE_INFINITY, 0) should be 0", 0, posInf0Range.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Testing equivalence class 14
	//Tests boundary condition upper bound Double.POSITIVE_INFINITY
	@Test
	public void getUpperBound_zeroPosInfRange_PosInf()
	{
		assertEquals("The upper bound of the range (0, POSITIVE_INFINITY) should be positive infinity", Double.POSITIVE_INFINITY, zeroPosInfRange.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Testing equivalence class 11
	//Tests boundary condition upper bound = Nominal
	@Test
	public void getUpperBound_negInf0Range_0()
	{
		assertEquals("The upper bound of the range (NEGATIVE_INFINITY, 0) should be 0", 0, negInf0Range.getUpperBound(), 0.000000001d);
	}
	
	//Tests the function getUpperBound() in the Range class
	//Testing range (0, NEGATIVE_INFINITY) is in the test case, but this is an invalid argument exception in the Range constructor
	//Tests equivalence class 13
	//Tests boundary condition upper bound = Double.NEGATIVE_INFINITY
	@Ignore 
	public void getUpperBound_zeroNegInfRange_0()
	{
		assertEquals("The upper bound of the range (0, NEGATIVE_INFINITY) should be 0", 0, zeroNegInfRange.getUpperBound(), 0.000000001d);
	}
	
	@After
	public void tearDown() throws Exception {
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	
}