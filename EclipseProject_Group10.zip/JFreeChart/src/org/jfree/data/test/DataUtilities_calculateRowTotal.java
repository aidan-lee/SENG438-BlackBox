package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities;
import org.jfree.data.Values2D;
import org.jmock.*;
import org.junit.*;

/**
 * Testing method static double calculateRowTotal(Values2D data, int row) in class
 * org.jfree.data.DataUtilities
 *
 */
public class DataUtilities_calculateRowTotal {
	
	@BeforeClass 
	public static void setUpBeforeClass() throws Exception {
		
	}
	@Before
	public void setUp() throws Exception {
		
	}

//===========================================================================
// TODO: null
	
	//Testing function [calculateRowTotal_ArraySizePlusOne_nullData] in class DataUtilities
	//Equivalence class: 2
	@Test
	public void calculateRowTotal_ArraySizePlusOne_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()+1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the first row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySize_nullData] in class DataUtilities
	//Equivalence class: 1
	@Test
	public void calculateRowTotal_ArraySize_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount());
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the 0th row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySizeMinusOne_nullData] in class DataUtilities
	//Equivalence class: 3
	@Test
	public void calculateRowTotal_ArraySizeMinusOne_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount() - 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the -1th row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_One_nullData] in class DataUtilities
	//Equivalence class: 1
	@Test
	public void calculateRowTotal_One_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the 1st row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Zero_nullData] in class DataUtilities
	//Equivalence class: 1
	@Test
	public void calculateRowTotal_Zero_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 0);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the 0th row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_NegOne_nullData] in class DataUtilities
	//Equivalence class: 1
	@Test
	public void calculateRowTotal_NegOne_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the -1st row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Max_nullData] in class DataUtilities
	//Equivalence class: 2
	@Test
	public void calculateRowTotal_Max_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the MAX_VALUEth row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_NegMax_nullData] in class DataUtilities
	//Equivalence class: 2
	@Test
	public void calculateRowTotal_NegMax_nullData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(null));
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the -MAX_VALUEth row of a null matrix with val[0][0] = 1 only should be 0", 0.0, result, 0.000000001d);
	}
	
	
//===========================================================================
// TODO: [0][0]
	
	//Testing function [calculateRowTotal_ArraySizePlusOne_ZeroZero] in class DataUtilities
	//Equivalence class: 5
	@Test
	public void calculateRowTotal_ArraySizePlusOne_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()+1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] row with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySize_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_ArraySize_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount());
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySizeMinusOne_ZeroZero] in class DataUtilities
	//Equivalence class: 6
	@Test
	public void calculateRowTotal_ArraySizeMinusOne_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount() - 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] row with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_One_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_One_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				for(int i = 0; i < 1; i++)
				{	
					if(i == 1)
					{
						oneOf(val).getValue(i, 0);
						will(returnValue(1));
					}
					else
					{
						oneOf(val).getValue(i, 0);
						will(returnValue(0));
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Nominal_NominalData] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Nominal_NominalData()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(2));
				allowing(val).getRowCount();
				will(returnValue(2));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < 2; i++)
				{	
					for(int j = 0; j < 2; j++)
					{
						if(i == 0 && j == 0)
						{
							oneOf(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()/2);
		//System.out.println(val.getColumnCount()/2);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Zero_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Zero_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				//allowing(val).getValue(0, 0);
				//will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 0);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_MinusOne_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_MinusOne_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Max_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Max_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_NegMax_ZeroZero] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_NegMax_ZeroZero()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(0));
				allowing(val).getRowCount();
				will(returnValue(0));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [0][0] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//===========================================================================
	// TODO: [1][1]
	
	//Testing function [calculateRowTotal_ArraySizePlusOne_OneOne] in class DataUtilities
	//Equivalence class: 5
	@Test
	public void calculateRowTotal_ArraySizePlusOne_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i <= 1; i++)
				{
					for(int j = 0; j <= 2; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()+1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySize_OneOne] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_ArraySize_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				for(int i = 0; i <= 1; i++)
				{
					for(int j = 0; j <= 1; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount());
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySizeMinusOne_OneOne] in class DataUtilities
	//Equivalence class: 6
	@Test
	public void calculateRowTotal_ArraySizeMinusOne_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount() - 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_One_OneOne] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_One_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				for(int i = 0; i <= 1; i++)
				{
					for(int j = 0; j <= 1; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Nominal_OneOne] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Nominal_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()/2);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Zero_OneOne] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Zero_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 0);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_MinusOne_OneOne] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_MinusOne_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = -1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Max_OneOne] in class DataUtilities
	//Equivalence class: 4
	//Can not be executed to to constraints on computer performance. Looping infinitely causes issues with the program.
	@Ignore
	public void calculateRowTotal_Max_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < Integer.MAX_VALUE; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_NegMax_OneOne] in class DataUtilities
	//Equivalence class: 4
	//Can not be executed to to constraints on computer performance. Looping infinitely causes issues with the program.
	@Ignore
	public void calculateRowTotal_NegMax_OneOne()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(1));
				allowing(val).getRowCount();
				will(returnValue(1));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 1; i < 1; i++)
				{
					oneOf(val).getValue(i, 0);
					will(returnValue(0));
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [1][1] matrix with val[0][0] = Neg infinity only should be Negative infinity", -Integer.MAX_VALUE, result, 0.000000001d);
	}	

	//===========================================================================
	// TODO: [10][10] Nominal case
	
	//Testing function [calculateRowTotal_ArraySizePlusOne_TenTen] in class DataUtilities
	//Equivalence class: 5
	@Test
	public void calculateRowTotal_ArraySizePlusOne_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i <= 11; i++)
				{
					for(int j = 0; j <= 11; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()+1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySize_TenTen] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_ArraySize_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i <= 10; i++)
				{
					for(int j = 0; j <= 10; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount());
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_ArraySizeMinusOne_TenTen] in class DataUtilities
	//Equivalence class: 6
	@Test
	public void calculateRowTotal_ArraySizeMinusOne_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < 10; i++)
				{
					for(int j = 0; j < 10; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount() - 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_One_TenTen] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_One_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				for(int i = 0; i < 10; i++)
				{	
					for(int j = 0; j < 10; j++) 
					{
						if(i == 0 && j == 0)
						{
							oneOf(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_MidVal_TenTen] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_MidVal_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < 10; i++)
				{
					for(int j = 0; j < 10; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, val.getRowCount()/2);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Zero_TenTen] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_Zero_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < 10; i++)
				{
					for(int j = 0; j < 10; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, 0);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 1", 1, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_MinusOne_TenTen] in class DataUtilities
	//Equivalence class: 4
	@Test
	public void calculateRowTotal_MinusOne_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = -1; i < 10; i++)
				{
					for(int j = 0; j < 10; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -1);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_Max_TenTen] in class DataUtilities
	//Equivalence class: 4
	//Can not be executed to to constraints on computer performance. Looping infinitely causes issues with the program.
	@Ignore
	public void calculateRowTotal_Max_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < Integer.MAX_VALUE; i++)
				{
					for(int j = 0; j < Integer.MAX_VALUE; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	//Testing function [calculateRowTotal_NegMax_TenTen] in class DataUtilities
	//Equivalence class: 4
	//Can not be executed to to constraints on computer performance. Looping infinitely causes issues with the program.
	@Ignore
	public void calculateRowTotal_NegMax_TenTen()
	{
		Mockery context = new Mockery();
		final Values2D val = context.mock(Values2D.class);
		context.checking(new Expectations() {
			{
				allowing(val).getColumnCount();
				will(returnValue(10));
				allowing(val).getRowCount();
				will(returnValue(10));
				allowing(val).getValue(0, 0);
				will(returnValue(1));
				for(int i = 0; i < Integer.MAX_VALUE; i++)
				{
					for(int j = 0; j < Integer.MAX_VALUE; j++)
					{
						if (i == 0 && j == 0)
						{
							allowing(val).getValue(i, j);
							will(returnValue(1));
						}
						else
						{
							oneOf(val).getValue(i, j);
							will(returnValue(0));
						}
					}
				}
			}
		});
		
		double result = DataUtilities.calculateRowTotal(val, -Integer.MAX_VALUE);
		//System.out.println(result);
		//System.out.println(val.getValue(0, 0));
		assertEquals("The total of the [10][10] matrix with val[0][0] = 1 only should be 0", 0, result, 0.000000001d);
	}
	
	@After
	public void tearDown() throws Exception {
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
