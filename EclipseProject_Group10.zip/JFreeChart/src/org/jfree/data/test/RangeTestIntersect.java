package org.jfree.data.test;
import static org.junit.Assert.*;
import org.jfree.data.Range;
import org.junit.*;

/**
 * Testing method boolean intersects(double lower, double upper) in class 
 * org.jfree.data.Range 
 *
 */
public class RangeTestIntersect {
	
	private Range exampleRange;
	
	@BeforeClass public static void setUpBeforeClass()
	throws Exception {
		
	}
	
	@Before
	public void setUp() throws Exception {
		
	}
	
	// Start testing method public boolean intersects(double lower, double upper)
	// Input variables: range (object of class Range), lower (double), upper (double)
	// Note: EC		= Equivalent Class
	//		 NOM	= Nominal
	//		 BLB	= Below Lower Bound
	//		 LB		= Lower Bound
	//		 ALB	= Above Lower Bound
	//		 BUB	= Below Upper Bound
	//		 UB		= Upper Bound
	//		 AUB	= Above Upper Bound
	
	// EC1, EC9, EC15, EC21; All input variables (range, lower, upper)
	// definite, NOM, and upper >= lower
	@Test
	public void test1_rangeAndupperAndlowerDefiniteAndlowerLessThanUpperNOMforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (-550.50505, 540.00001) should NOT "
				+ "intersect with the range (-600, -551)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC1; BUB definite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test2_rangeDefiniteBUBforMethodIntersects() {
		exampleRange = new Range(-Double.MAX_VALUE + 1, Double.MAX_VALUE - 1);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(-Double.MAX_VALUE + 1, Double.MAX_VALUE - 1)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC1; UB definite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test3_rangeDefiniteUBforMethodIntersects() {
		exampleRange = new Range(-Double.MAX_VALUE, Double.MAX_VALUE);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(-Double.MAX_VALUE, Double.MAX_VALUE)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC2; NOM negative infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test4_rangeNegInfiniteNOMforMethodIntersects() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, 500);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range (Double.NEGATIVE_INFINITY, 500)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC2; BUB negative infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test5_rangeNegInfiniteBUBforMethodIntersects() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.MAX_VALUE - 1);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(Double.NEGATIVE_INFINITY, Double.MAX_VALUE - 1)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC2; UB negative infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test6_rangeNegInfiniteUBforMethodIntersects() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.MAX_VALUE);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(Double.NEGATIVE_INFINITY, Double.MAX_VALUE)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC3; NOM positive infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test7_rangePosInfiniteNOMforMethodIntersects() {
		exampleRange = new Range(541, Double.POSITIVE_INFINITY);
		assertFalse("The specified range (-550.50505, 540.00001) should NOT "
				+ "intersect with the range (541, Double.POSITIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC3; BUB positive infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test8_rangePosInfiniteBUBforMethodIntersects() {
		exampleRange = new Range(-Double.MAX_VALUE + 1, Double.POSITIVE_INFINITY);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(-Double.MAX_VALUE + 1, Double.POSITIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC3; UB positive infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test9_rangePosInfiniteUBforMethodIntersects() {
		exampleRange = new Range(-Double.MAX_VALUE, Double.POSITIVE_INFINITY);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(-Double.MAX_VALUE, Double.POSITIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC4; Infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test10_rangeInfiniteforMethodIntersects() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
		assertTrue("The specified range (-550.50505, 540.00001) should "
				+ "intersect with the range "
				+ "(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC5; Invalid negative infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test11_rangeInvalidNegInfiniteforMethodIntersects() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
		assertFalse("The specified range (-550.50505, 540.00001) should NOT"
				+ "intersect with the range "
				+ "(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC6; Invalid positive infinite range, lower and upper definite and NOM, upper >= lower
	@Test
	public void test12_rangeInvalidPosInfiniteforMethodIntersects() {
		exampleRange = new Range(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
		assertFalse("The specified range (-550.50505, 540.00001) should NOT"
				+ "intersect with the invalid range "
				+ "(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC7; Invalid range (not a number), lower and upper definite and NOM, upper >= lower
	@Test
	public void test13_rangeNotANumberforMethodIntersects() {
		exampleRange = new Range(Double.NaN, Double.NaN);
		assertFalse("The specified range (-550.50505, 540.00001) should NOT"
				+ "intersect with the invalid range (Double.NaN, Double.NaN)",
						exampleRange.intersects(-550.50505, 540.00001));
	}
	
	// EC8; Invalid range (null), lower and upper definite and NOM, upper >= lower
	@Test
	public void test14_rangeNullforMethodIntersects() {
		exampleRange = null;
		try {
			assertFalse("The specified range (-550.50505, 540.00001) should NOT"
				+ "intersect with a null range",
						exampleRange.intersects(-550.50505, 540.00001));
		}catch(NullPointerException e) {
			assertTrue(true);
		}
	}
	
	// EC10; BLB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test15_lowerDefiniteBLBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (-Double.MAX_VALUE - 1, -100.00001) "
				+ "has an invalid lower bound value and thus should NOT "
				+ "intersect with the range (-600, -551)",
						exampleRange.intersects(-Double.MAX_VALUE - 1, -100.00001));
	}
	
	// EC9; LB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test16_lowerDefiniteLBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertTrue("The specified range (-Double.MAX_VALUE, -100.00001) "
				+ "should intersect with the range (-600, -551)",
						exampleRange.intersects(-Double.MAX_VALUE, -100.00001));
	}
	
	// EC9; ALB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test17_lowerDefiniteALBforMethodIntersects() {
		exampleRange = new Range(-100, 0);
		assertTrue("The specified range (-Double.MAX_VALUE + 1, -100.00001) "
				+ "should intersect with the range (-100, 0)",
						exampleRange.intersects(-Double.MAX_VALUE + 1, -100.00001));
	}
	
	// EC9; BUB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test18_lowerDefiniteBUBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.MAX_VALUE - 1, Double.MAX_VALUE) "
				+ "should NOT intersect with the range (-600, -551)",
						exampleRange.intersects(Double.MAX_VALUE - 1, Double.MAX_VALUE));
	}
	
	// EC9; UB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test19_lowerDefiniteUBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.MAX_VALUE, Double.MAX_VALUE) "
				+ "should NOT intersect with the range (-600, -551)",
						exampleRange.intersects(Double.MAX_VALUE, Double.MAX_VALUE));
	}
	
	// EC11; AUB definite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test20_lowerDefiniteAUBforMethodIntersects() {
		exampleRange = new Range(-600, Double.MAX_VALUE);
		assertFalse("The specified range (Double.MAX_VALUE + 1, Double.POSITIVE_INFINITY) "
				+ "has an invalid lower bound value and thus "
				+ "should NOT intersect with the range (-600, Double.MAX_VALUE)",
				exampleRange.intersects(Double.MAX_VALUE + 1, Double.POSITIVE_INFINITY));
	}
	
	// EC12, EC 23; Negative infinite lower, range and upper definite and NOM, upper >= lower
	@Test
	public void test21_lowerNegInfiniteforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertTrue("The specified range (Double.NEGATIVE_INFINITY, 0) "
				+ "should intersect with the range (-600, -551)",
						exampleRange.intersects(Double.NEGATIVE_INFINITY, 0));
	}
	
	// EC13, EC27; Positive infinite lower and upper, range NOM, upper >= lower
	@Test
	public void test22_lowerAndrupperPosInfiniteforMethodIntersects() {
		exampleRange = new Range(-600, 500);
		assertFalse("The specified range (Double.POSITIVE_INFINITY, "
				+ "Double.POSITIVE_INFINITY) is an invalid range and thus "
				+ "should NOT intersect with the range (-600, 500)",
			exampleRange.intersects(Double.POSITIVE_INFINITY, 
					Double.POSITIVE_INFINITY));
	}
	
	// EC14; Invalid lower (not a number), range and upper definite and NOM
	@Test
	public void test23_lowerNotANumberforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.NaN, 0) "
				+ "should NOT intersect with the range (-600, -551)",
						exampleRange.intersects(Double.NaN, 0));
	}
	
	// EC16; BLB definite upper, range definite, range and lower NOM, upper >= lower
	@Test
	public void test24_upperDefiniteBLBforMethodIntersects() {
		exampleRange = new Range(-Double.MAX_VALUE, -551);
		assertFalse("The specified range "
				+ "(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE - 1) "
				+ "has an invalid upper bound value and thus should NOT "
				+ "intersect with the range (-Double.MAX_VALUE, -551)",
				exampleRange.intersects(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE - 1));
	}
	
	// EC15; LB definite upper, range definite, range and lower NOM, upper >= lower
	@Test
	public void test25_upperDefiniteLBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.NEGATIVE_INFINITY, -Double.MAX_VALUE) "
				+ "should NOT intersect with the range (-600, -551)",
				exampleRange.intersects(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE));
	}
	
	// EC15; ALB definite upper, range definite, range and lower NOM, upper >= lower
	@Test
	public void test26_upperDefiniteALBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.NEGATIVE_INFINITY, -Double.MAX_VALUE + 1) "
				+ "should NOT intersect with the range (-600, -551)",
				exampleRange.intersects(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE + 1));
	}
	
	// EC15; BUB definite upper, range and lower definite and NOM, upper >= lower
	@Test
	public void test27_upperDefiniteBUBforMethodIntersects() {
		exampleRange = new Range(-600, 551);
		assertTrue("The specified range (-1.03993, Double.MAX_VALUE - 1) "
				+ "should intersect with the range (-600, 551)",
					exampleRange.intersects(-1.03993, Double.MAX_VALUE - 1));
	}
	
	// EC15; UB definite upper, range and lower definite and NOM, upper >= lower
	@Test
	public void test28_upperDefiniteUBforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (-0.00001, Double.MAX_VALUE) "
				+ "should NOT intersect with the range (-600, -551)",
						exampleRange.intersects(-0.00001, Double.MAX_VALUE));
	}
	
	// EC17; AUB definite upper, range and lower definite and NOM, upper >= lower
	@Test
	public void test29_upperDefiniteAUBforMethodIntersects() {
		exampleRange = new Range(-600, 3);
		assertFalse("The specified range (0, Double.MAX_VALUE + 1) "
				+ "has an invalid upper bound value and thus "
				+ "should NOT intersect with the range (-600, 3)",
				exampleRange.intersects(0, Double.MAX_VALUE + 1));
	}
	
	// EC18, EC26; Negative infinite upper and lower, range definite and NOM, upper >= lower
	@Test
	public void test30_upperAndlowerNegInfiniteforMethodIntersects() {
		exampleRange = new Range(-600, 0);
		assertFalse("The specified range (Double.NEGATIVE_INFINITY, "
				+ "Double.NEGATIVE_INFINITY) is an invalid range and thus "
				+ "should NOT intersect with the range (-600, 0)",
			exampleRange.intersects(Double.NEGATIVE_INFINITY, 
					Double.NEGATIVE_INFINITY));
	}
	
	// EC19, EC24; Positive infinite upper, range and lower definite and NOM, upper >= lower
	@Test
	public void test31_upperPosInfiniteforMethodIntersects() {
		exampleRange = new Range(-600, 100);
		assertFalse("The specified range (200, Double.POSITIVE_INFINITY) "
				+ "should NOT intersect with the range (-600, 100)",
						exampleRange.intersects(200, Double.POSITIVE_INFINITY));
	}
	
	// EC20; Invalid upper (not a number), range and lower definite and NOM
	@Test
	public void test32_upperNotANumberforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (0, Double.NaN) "
				+ "should NOT intersect with the range (-600, -551)",
						exampleRange.intersects(0, Double.NaN));
	}
	
	// EC22; lower > upper, definite lower and upper, range definite and NOM
	@Test
	public void test33_lowerGreaterThanupperforMethodIntersects() {
		exampleRange = new Range(-600, 551);
		assertFalse("The specified range (1000, 0) "
				+ "has lower bound > upper bound which is an invalid range "
				+ "and thus should NOT intersect with the range (-600, 551)",
						exampleRange.intersects(1000, 0));
	}
	
	// EC25; lower < upper, infinite lower and upper, range definite and NOM
	@Test
	public void test34_lowerLessThanupperInfiniteforMethodIntersects() {
		exampleRange = new Range(0, 100);
		assertTrue("The specified range "
				+ "(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY) "
				+ "should intersect with the range (0, 100)",
				exampleRange.intersects(Double.NEGATIVE_INFINITY, 
						Double.POSITIVE_INFINITY));
	}
	
	// EC28; lower > upper, infinite lower and upper, range definite and NOM
	@Test
	public void test35_lowerGreaterThanupperInfiniteforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range "
				+ "(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY) "
				+ "has lower bound > upper bound which is an invalid range "
				+ "and thus should NOT intersect with the range (-600, -551)",
				exampleRange.intersects(Double.POSITIVE_INFINITY, 
								Double.NEGATIVE_INFINITY));
	}
	
	// EC29; Invalid upper and lower (not a number), range definite and NOM
	@Test
	public void test36_upperAndlowerNotANumberforMethodIntersects() {
		exampleRange = new Range(-600, -551);
		assertFalse("The specified range (Double.NaN, Double.NaN) "
				+ "is an invalid range and thus should NOT"
				+ "intersect with the range (-600, -551)",
					exampleRange.intersects(Double.NaN, Double.NaN));
	}
	// End testing method public boolean intersects(double lower, double upper)
	
	@After
	public void tearDown() throws Exception {
		exampleRange = null;
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}
}