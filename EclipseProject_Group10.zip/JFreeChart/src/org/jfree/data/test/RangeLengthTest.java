package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.Range;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 * Testing method double getLength() in class org.jfree.data.Range 
 *
 */
public class RangeLengthTest {
	private Range nullRange;
	
	private Range upperMaxRangePlusOne;
	private Range upperMaxRange;
	private Range upperMaxRangeMinusOne;
	
	private Range lowerMaxRangePlusOne;
	private Range lowerMaxRange;
	private Range lowerMaxRangeMinusOne;
	
	private Range upperMinRangePlusOne;
	private Range upperMinRange;
	private Range upperMinRangeMinusOne;
	
	private Range lowerMinRangePlusOne;
	private Range lowerMinRange;
	private Range lowerMinRangeMinusOne;
	
	private Range minMaxRangePlusOne;
	private Range minMaxRange;
	private Range minMaxRangeMinusOne;
	
	private Range maxMinRangePlusOne;
	private Range maxMinRange;
	private Range maxMinRangeMinusOne;
	
	private Range upperPosInf;
	private Range upperNegInf;
	
	private Range lowerPosInf;
	private Range lowerNegInf;
	
	private Range posNegInf;
	private Range negPosInf;
	
	private Range zeroRange;

	private Range maxMaxRangePlusOne;
	private Range maxMaxRange;
	private Range maxMaxRangeMinusOne;

	private Range minMinRangePlusOne;
	private Range minMinRange;
	private Range minMinRangeMinusOne;

	private Range posInf;
	private Range negInf;
	
	private Range upperNanRange;
	private Range lowerNanRange;
	private Range NanRange;
	

	@BeforeClass 
	public static void setUpBeforeClass() throws Exception {
		
	}
	@Before
	public void setUp() throws Exception {
		//Note that the objects that are commented out cannot be constructed,
		//due the Range constructor requiring the first argument to be smaller
		//than the second
		
		nullRange = null;
		
		upperMaxRangePlusOne = new Range(0, Double.MAX_VALUE+1);
		upperMaxRange = new Range(0, Double.MAX_VALUE);
		upperMaxRangeMinusOne = new Range(0, Double.MAX_VALUE-1);
		
		//lowerMaxRangePlusOne = new Range(Double.MAX_VALUE+1, 0);
		//lowerMaxRange = new Range(Double.MAX_VALUE, 0);
		//lowerMaxRangeMinusOne = new Range(Double.MAX_VALUE-1, 0);
		
		//upperMinRangePlusOne = new Range(0, -Double.MAX_VALUE+1);
		//upperMinRange = new Range(0, -Double.MAX_VALUE);
		//upperMinRangeMinusOne = new Range(0, -Double.MAX_VALUE-1);
		
		lowerMinRangePlusOne = new Range(-Double.MAX_VALUE+1, 0);
		lowerMinRange = new Range(-Double.MAX_VALUE, 0);
		lowerMinRangeMinusOne = new Range(-Double.MAX_VALUE-1, 0);
		
		minMaxRangePlusOne = new Range(-Double.MAX_VALUE+1, Double.MAX_VALUE+1);
		minMaxRange = new Range(-Double.MAX_VALUE, Double.MAX_VALUE);
		minMaxRangeMinusOne = new Range(-Double.MAX_VALUE-1, Double.MAX_VALUE-1);
		
		//maxMinRangePlusOne = new Range(Double.MAX_VALUE + 1, -Double.MAX_VALUE + 1);
		//maxMinRange = new Range(Double.MAX_VALUE, -Double.MAX_VALUE);
		//maxMinRangeMinusOne = new Range(Double.MAX_VALUE - 1, -Double.MAX_VALUE - 1);
		
		upperPosInf = new Range(0, Double.POSITIVE_INFINITY); //stopped here
		//upperNegInf = new Range(0, Double.NEGATIVE_INFINITY);
		
		//lowerPosInf = new Range(Double.POSITIVE_INFINITY, 0);
		lowerNegInf = new Range(Double.NEGATIVE_INFINITY, 0);
		
		//posNegInf = new Range(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
		negPosInf = new Range(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
		
		zeroRange = new Range(0, 0);
		
		maxMaxRangePlusOne = new Range(Double.MAX_VALUE + 1, Double.MAX_VALUE + 1);
		maxMaxRange = new Range(Double.MAX_VALUE, Double.MAX_VALUE);
		maxMaxRangeMinusOne = new Range(Double.MAX_VALUE - 1, Double.MAX_VALUE - 1);
		
		minMinRangePlusOne = new Range(-Double.MAX_VALUE + 1, -Double.MAX_VALUE + 1);
		minMinRange = new Range(-Double.MAX_VALUE, -Double.MAX_VALUE);
		minMinRangeMinusOne = new Range(-Double.MAX_VALUE - 1, -Double.MAX_VALUE - 1);
		
		posInf = new Range(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
		negInf = new Range(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
		
		upperNanRange = new Range(0, Double.NaN);
		lowerNanRange = new Range(Double.NaN, 0);
		NanRange = new Range(Double.NaN, Double.NaN);
		
	}

	//Tests the function getLength() in the Range class
	//Part of the equivalence classes but cannot be executed, due to a null pointer exception
	//Tests equivalence class 1
	@Ignore
	public void getLength_nullRange_Null() {
		assertNull("The length of a null range should be null", nullRange.getLength());
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 14
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Test
	public void getLength_upperMaxRangePlusOne_MaxPlusOne() {
		assertEquals("The length of range (0,max+1) should be max+1", Double.MAX_VALUE+1, upperMaxRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 8, 14
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Test
	public void getLength_upperMaxRange_Max() {
		assertEquals("The length of range (0,max) should be max", Double.MAX_VALUE, upperMaxRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 14, 15
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Test
	public void getLength_upperMaxRangeMinusOne_MaxMinusOne() {
		assertEquals("The length of range (0,max-1) should be max-1", Double.MAX_VALUE-1, upperMaxRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE + 1, 0) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 15
	//Tests boundary condition upper bound = Nominal, lower bound = Double.MAX_VALUE
	@Ignore
	public void getLength_lowerMaxRangePlusOne_MaxMinusOne()
	{
		assertEquals("The length of range (max+1, 0) should be max + 1", Double.MAX_VALUE + 1, lowerMaxRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE, 0) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 7, 15
	//Tests boundary condition upper bound = Nominal, lower bound = Double.MAX_VALUE
	@Ignore
	public void getLength_lowerMaxRange_MaxMinusOne()
	{
		assertEquals("The length of range (max, 0) should be max", Double.MAX_VALUE, lowerMaxRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE + 1, 0) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 14, 15
	//Tests boundary condition upper bound = Nominal, lower bound = Double.MAX_VALUE
	@Ignore
	public void getLength_lowerMaxRangeMinusOne_MaxMinusOne()
	{
		assertEquals("The length of range (max-1, 0) should be max - 1", Double.MAX_VALUE - 1, lowerMaxRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (0, -Double.MAX_VALUE + 1) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 10, 14, 15
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Ignore
	public void getLength_upperMinRangePlusOne_MinPlusOne()
	{
		assertEquals("The length of range (0, min + 1) should be abs(min + 1)", Double.MAX_VALUE, upperMinRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (0, -Double.MAX_VALUE) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 12, 14
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Ignore
	public void getLength_upperMinRange_Min()
	{
		assertEquals("The length of range (0, min) should be abs(min)", Double.MAX_VALUE, upperMinRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (0, -Double.MAX_VALUE - 1) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 4, 14
	//Tests boundary condition upper bound = -Double.MAX_VALUE, lower bound = Nominal
	@Ignore
	public void getLength_upperMinRange_Max()
	{
		assertEquals("The length of range (0, min - 1) should be abs(min - 1)", Double.MAX_VALUE - 1, upperMinRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 14, 15
	//Tests boundary condition upper bound = Nominal, lower bound = -Double.MAX_VALUE
	@Test
	public void getLength_lowerMinRangePlusOne_MaxPlusOne() {
		assertEquals("The length of range (min+1,0) should be abs(min+1)", Double.MAX_VALUE+1, lowerMinRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 11, 15
	//Tests boundary condition upper bound = Nominal, lower bound = -Double.MAX_VALUE
	@Test
	public void getLength_lowerMinRange_Min() {
		assertEquals("The length of range (min,0) should be abs(min)", Double.MAX_VALUE, lowerMinRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 9, 15
	//Tests boundary condition upper bound = Nominal, lower bound = -Double.MAX_VALUE
	@Test
	public void getLength_lowerMinRangeMinusOne_AbsMinMinusOne() {
		assertEquals("The length of range (min-1,0) should be abs(min-1)", Double.MAX_VALUE-1, lowerMinRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 14
	//Tests boundary conditions lower bound = -Double.MAX_VALUE + 1 and upper bound = Double.MAX_VALUE + 1
	@Test
	public void getLength_minMaxRangePlusOne_2MaxPlusOne() {
		assertEquals("The length of range (min+1,max+1) should be 2 * max+1",( Double.MAX_VALUE+1) * 2, minMaxRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 8, 11
	//Tests boundary conditions lower bound = -Double.MAX_VALUE and upper bound = Double.MAX_VALUE
	@Test
	public void getLength_minMaxRange_2Max() {
		assertEquals("The length of range (min,max) should be 2 * max", Double.MAX_VALUE * 2, minMaxRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 6, 9, 15
	//Tests boundary conditions lower bound = -Double.MAX_VALUE - 1 and upper bound = Double.MAX_VALUE - 1
	@Test
	public void getLength_minMaxRangeMinusOne_2MaxMinusOne() {
		assertEquals("The length of range (min-1,max-1) should be 2 * max-1",( Double.MAX_VALUE-1) * 2, minMaxRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE + 1, -Double.MAX_VALUE + 1) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 5, 7, 10 15
	//Tests boundary conditions lower bound = Double.MAX_VALUE and upper bound = -Double.MAX_VALUE
	@Ignore
	public void getLength_maxMinRangePlusOne_2MaxPlusOne()
	{
		assertEquals("The length of range (max+1, min+1) should be 2 * max+1", (Double.MAX_VALUE + 1)*2, maxMinRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE, -Double.MAX_VALUE) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 5, 7, 12
	//Tests boundary conditions lower bound = Double.MAX_VALUE and upper bound = -Double.MAX_VALUE
	@Ignore
	public void getLength_maxMinRange_2Max()
	{
		assertEquals("The length of range (max, min) should be 2 * max", (Double.MAX_VALUE)*2, maxMinRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.MAX_VALUE - 1, -Double.MAX_VALUE) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 5, 7, 14
	//Tests boundary conditions lower bound = Double.MAX_VALUE and upper bound = -Double.MAX_VALUE
	@Ignore
	public void getLength_maxMinRangeMinusOne_2MaxMinusOne()
	{
		assertEquals("The length of range (max-1, min-1) should be 2* max-1", (Double.MAX_VALUE - 1)*2, maxMinRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 14, 21
	//Tests boundary condition upper bound = Double.POSITIVE_INFINITY, lower bound = Nominal
	@Test
	public void getLength_upperPosInf_PosInf()
	{
		assertEquals("The length of range (0, positive infinity) should be positive infinity", Double.POSITIVE_INFINITY, upperPosInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (0,  Double.NEGATIVE_INFINITY) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 14, 19
	//Tests boundary conditions upper bound = Double.NEGATIVE INFINITY, lower bound = Nominal
	@Ignore
	public void getLength_upperNegInf_PosInf()
	{
		assertEquals("The length of range (0, negative infinity) should be abs(negative infinity)", Double.POSITIVE_INFINITY, upperNegInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.POSITIVE_INFINITY, 0) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 15, 20
	//Tests boundary conditions upper bound = Double.POSITIVE_INFINITY, lower bound = Nominal
	@Ignore
	public void getLength_lowerPosInf_PosInf()
	{
		assertEquals("The length of range (positive infinity, 0) should be positive infinity", Double.POSITIVE_INFINITY, lowerPosInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 15, 18
	//Tests boundary condition upper bound = Nominal, lower bound = Double.NEGATIVE_INFINITY
	@Test
	public void getLength_lowerNegInf_PosInf()
	{
		assertEquals("The length of range (negative infinity, 0) should be abs(negative infinity)", Double.POSITIVE_INFINITY, lowerNegInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Testing the range (Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY) is part of the test cases, but cannot be executed due to Range constructor constraints
	//Tests equivalence class 19, 20 
	//Tests boundary conditions lower bound = Double.POSITIVE_INFINITY and upper bound = Double.NEGATIVE_INFINITY
	@Ignore
	public void getLength_posNegInf_2Inf()
	{
		assertEquals("The length of range (positive infinity, negative infinity) should be 2*(positive infinity)", 2*(Double.POSITIVE_INFINITY), posNegInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 18, 21
	//Tests boundary conditions lower bound = Double.NEGATIVE_INFINITY and upper bound = Double.POSITIVE_INFINITY
	@Test
	public void getLength_negPosInf_2Inf()
	{
		assertEquals("The length of range (negative infinity, positive infinity) should be 2*(positive infinity)", 2*(Double.POSITIVE_INFINITY), negPosInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence classes 14, 17
	//Tests boundary condition upper bound = Double.NaN, lower bound = Nominal
	@Test
	public void getLength_upperNanRange_0()
	{
		assertEquals("The length of range (0, NaN) should be 0", 0, upperNanRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence classes 15, 16
	//Tests boundary condition upper bound = Double.NaN, lower bound = Nominal
	@Test
	public void getLength_lowerNanRange_0()
	{
		assertEquals("The length of range (NaN, 0) should be 0", 0, lowerNanRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 13, 14
	//Tests boundary condition lower bound = upper bound
	@Test
	public void getLength_zeroRange_0()
	{
		assertEquals("The length of range (0, 0) should be 0", 0, zeroRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2, 10
	//Tests boundary conditions lower bound = Double.MAX_VALUE, upper bound = Double.MAX_VALUE, and lower bound = upper bound
	@Test
	public void getLength_maxMaxRangePlusOne_0()
	{
		assertEquals("The length of range (max+1, max+1) should be 0", 0, maxMaxRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2, 7, 8
	//Tests boundary conditions lower bound = Double.MAX_VALUE, upper bound = Double.MAX_VALUE, lower bound = upper bound
	@Test
	public void getLength_maxMaxRange_0()
	{
		assertEquals("The length of range (max, max) should be 0", 0, 	maxMaxRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2, 14, 15
	//Tests boundary conditions lower bound = Double.MAX_VALUE, upper bound = Double.MAX_VALUE, and lower bound = upper bound
	@Test
	public void getLength_maxMaxRangeMinusOne_0()
	{
		assertEquals("The length of range (max-1, max-1) should be 0", 0, maxMaxRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2, 9 , 10
	//Tests boundary conditions lower bound = -Double.MAX_VALUE, upper bound = -Double.MAX_VALUE, and lower bound = upper bound
	@Test
	public void getLength_minMinRangePlusOne_0()
	{
		assertEquals("The length of range (min+1, min+1) should be 0", 0, minMinRangePlusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2, 11, 12
	//Tests boundary conditions lower bound = -Double.MAX_VALUE, upper bound = -Double.MAX_VALUE, and lower bound = upper bound
	@Test
	public void getLength_minMinRange_0()
	{
		assertEquals("The length of range (min, min) should 0", 0, minMinRange.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 2
	//Tests boundary conditions lower bound = -Double.MAX_VALUE - 1, upper bound = -Double.MAX_VALUE - 1, and lower bound = upper bound 
	@Test
	public void getLength_minMinRangeMinusOne_0()
	{
		assertEquals("The length of range (min-1, min-1) should be 0", 0, minMinRangeMinusOne.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 3, 20 , 21
	//Tests boundary conditions lower bound = Double.POSITIVE_INFINITY, upper bound = Double.POSITIVE_INFINITY, and lower bound = upper bound
	@Test
	public void getLength_posInf_0()
	{
		assertEquals("The length of range (positive infinity, positive infinity) should be 0", 0, posInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalence class 3, 18, 19
	//Tests boundary conditions lower bound = Double.NEGATIVE_INFINITY, upper bound = Double.POSITIVE_INFINITY, and lower bound = upper bound
	@Test
	public void getLength_negInf_0()
	{
		assertEquals("The length of range (negative infinity, negative infinity) should be 0", 0, negInf.getLength(), 0.000000001d);
	}
	
	//Tests the function getLength() in the Range class
	//Tests equivalnce classes 2, 16, 17
	//Tests boundary conditions lower bound = Double.NaN, upper bound = Double.NaN
	@Test
	public void getLength_NanRange_0()
	{
		assertEquals("The length of range (NaN, NaN) should be 0", 0, NanRange.getLength(), 0.000000001d);
	}
	
	@After
	public void tearDown() throws Exception {
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
