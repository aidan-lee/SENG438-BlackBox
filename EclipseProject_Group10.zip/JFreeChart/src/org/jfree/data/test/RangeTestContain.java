package org.jfree.data.test;
import static org.junit.Assert.*;
import org.jfree.data.Range;
import org.junit.*;

/**
 * Testing method boolean contains(double value) in class 
 * org.jfree.data.Range 
 *
 */
public class RangeTestContain {
	
	private Range exampleRange;
	
	@BeforeClass public static void setUpBeforeClass()
	throws Exception {
		
	}
	
	@Before
	public void setUp() throws Exception {
		
	}
	
	// Start testing method public boolean contains(double value)
	// Input variables: range (object of class Range), value (double)
	// Note: EC		= Equivalent Class
	//		 NOM	= Nominal
	//		 BLB	= Below Lower Bound
	//		 LB		= Lower Bound
	//		 ALB	= Above Lower Bound
	//		 BUB	= Below Upper Bound
	//		 UB		= Upper Bound
	//		 AUB	= Above Upper Bound
	 
	// EC1, EC9; All input variables (range, value) definite and NOM  
	@Test
	public void test1_rangeAndvalueDefiniteNOMforMethodContains() {
		exampleRange = new Range(-600, -551);
		assertFalse("The value 0 should NOT be within -600 and -551",
				exampleRange.contains(0));
	}
	
	// EC1; BUB definite range, NOM value
	@Test
	public void test2_rangeDefiniteBUBforMethodContains() {
		exampleRange = new Range(-Double.MAX_VALUE + 1, Double.MAX_VALUE - 1);
		assertTrue("The value 0 should be within -Double.MAX_VALUE + 1 "
				+ "and Double.MAX_VALUE - 1", exampleRange.contains(0));
	}
	
	// EC1; UB definite range, NOM value
	@Test
	public void test3_rangeDefiniteUBforMethodContains() {
		exampleRange = new Range(-Double.MAX_VALUE, Double.MAX_VALUE);
		assertTrue("The value 0 should be within -Double.MAX_VALUE "
				+ "and Double.MAX_VALUE", exampleRange.contains(0));
	}
	
	// EC2; NOM negative infinite range, NOM value
	@Test
	public void test4_rangeNegInfiniteNOMforMethodContains() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, 500);
		assertTrue("The value -500 should be within Double.NEGATIVE_INFINITY "
				+ "and 500", exampleRange.contains(-500));
	}
	
	// EC2; BUB negative infinite range, NOM value
	@Test
	public void test5_rangeNegInfiniteBUBforMethodContains() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.MAX_VALUE - 1);
		assertTrue("The value -500 should be within Double.NEGATIVE_INFINITY "
				+ "and Double.MAX_VALUE - 1", exampleRange.contains(-500));
	}
	
	// EC2; UB negative infinite range, NOM value
	@Test
	public void test6_rangeNegInfiniteUBforMethodContains() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.MAX_VALUE);
		assertTrue("The value -500 should be within Double.NEGATIVE_INFINITY "
				+ "and Double.MAX_VALUE", exampleRange.contains(-500));
	}
	
	// EC3; NOM positive infinite range, NOM value
	@Test
	public void test7_rangePosInfiniteNOMforMethodContains() {
		exampleRange = new Range(541, Double.POSITIVE_INFINITY);
		assertFalse("The value -500 should NOT be within 541 and "
				+ "Double.POSITIVE_INFINITY", exampleRange.contains(-500));
	}
	
	// EC3; BUB positive infinite range, NOM value
	@Test
	public void test8_rangePosInfiniteBUBforMethodContains() {
		exampleRange = new Range(-Double.MAX_VALUE + 1, Double.POSITIVE_INFINITY);
		assertTrue("The value -500 should be within "
				+ "-Double.MAX_VALUE + 1 and Double.POSITIVE_INFINITY", 
				exampleRange.contains(-500));
	}
	
	// EC3; UB positive infinite range, NOM value
	@Test
	public void test9_rangePosInfiniteUBforMethodContains() {
		exampleRange = new Range(-Double.MAX_VALUE, Double.POSITIVE_INFINITY);
		assertTrue("The value -500 should be within "
				+ "-Double.MAX_VALUE and Double.POSITIVE_INFINITY", 
				exampleRange.contains(-500));
	}
	
	// EC4; Infinite range, NOM value
	@Test
	public void test10_rangeInfiniteforMethodContains() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
		assertTrue("The value 0 should be within "
				+ "Double.NEGATIVE_INFINITY and Double.POSITIVE_INFINITY",
						exampleRange.contains(0));
	}
	
	// EC5; Invalid negative infinite range, NOM value
	@Test
	public void test11_rangeInvalidNegInfiniteforMethodContains() {
		exampleRange = new Range(Double.NEGATIVE_INFINITY, 
				Double.NEGATIVE_INFINITY);
		assertFalse("The value -100 should NOT be within "
				+ "Double.NEGATIVE_INFINITY and Double.NEGATIVE_INFINITY as "
				+ "this is an invalid range", exampleRange.contains(-100));
	}
	
	// EC6; Invalid positive infinite range, NOM value
	@Test
	public void test12_rangeInvalidPosInfiniteforMethodContains() {
		exampleRange = new Range(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
		assertFalse("The value 100 should NOT be within "
				+ "Double.POSITIVE_INFINITY and Double.POSITIVE_INFINITY as "
				+ "this is an invalid range", exampleRange.contains(100));
	}
	
	// EC7; Invalid range (not a number), NOM value
	@Test
	public void test13_rangeNotANumberforMethodContains() {
		exampleRange = new Range(Double.NaN, Double.NaN);
		assertFalse("The value 0 should NOT be within "
				+ "Double.NaN and Double.NaN as "
				+ "this is an invalid range", exampleRange.contains(0));
	}
	
	// EC8; Invalid range (null), NOM value
	@Test
	public void test14_rangeNullforMethodContains() {
		exampleRange = null;
		try {
			assertFalse("The value 0 should NOT be contained within a "
					+ "null range", exampleRange.contains(0));
		}catch(NullPointerException e) {
			assertTrue(true);
		}
	}
	
	// EC10; BLB value, NOM definite range
	@Test
	public void test15_valueDefiniteBLBforMethodContains() {
		exampleRange = new Range(-1, 1);
		assertFalse("The value (-Double.MAX_VALUE - 1) should NOT be "
				+ "within -1 and 1",
				exampleRange.contains(-Double.MAX_VALUE - 1));
	}
	
	// EC9; LB value, NOM definite range
	@Test
	public void test16_valueDefiniteLBforMethodContains() {
		exampleRange = new Range(-1, 1);
		assertFalse("The value -Double.MAX_VALUE should NOT be "
				+ "within -1 and 1",
				exampleRange.contains(-Double.MAX_VALUE));
	}
	
	// EC9; ALB value, NOM definite range
	@Test
	public void test17_valueDefiniteALBforMethodContains() {
		exampleRange = new Range(-1, 1);
		assertFalse("The value (-Double.MAX_VALUE + 1) should NOT be "
				+ "within -1 and 1",
				exampleRange.contains(-Double.MAX_VALUE + 1));
	}
	
	// EC9; BUB value, NOM definite range
	@Test
	public void test18_valueDefiniteBUBforMethodContains() {
		exampleRange = new Range(-1, 1);
		assertFalse("The value (Double.MAX_VALUE - 1) should NOT be "
				+ "within -1 and 1",
				exampleRange.contains(Double.MAX_VALUE - 1));
	}
	
	// EC9; UB value, NOM definite range
	@Test
	public void test19_valueDefiniteUBforMethodContains() {
		exampleRange = new Range(-1, Double.MAX_VALUE);
		assertTrue("The value Double.MAX_VALUE should be "
				+ "within -1 and Double.MAX_VALUE",
				exampleRange.contains(Double.MAX_VALUE));
	}
	
	// EC11; AUB value, NOM definite range
	@Test
	public void test20_valueDefiniteAUBforMethodContains() {
		exampleRange = new Range(-1, Double.MAX_VALUE);
		assertFalse("The value (Double.MAX_VALUE + 1) should NOT be "
				+ "within -1 and Double.MAX_VALUE",
				exampleRange.contains(Double.MAX_VALUE + 1));
	}
	
	// EC12; Negative infinity value, NOM definite range
	@Test
	public void test21_valueNegInfinityforMethodContains() {
		exampleRange = new Range(-100, 100);
		assertFalse("The value Double.NEGATIVE_INFINITY should NOT be "
				+ "within -100 and 100",
				exampleRange.contains(Double.NEGATIVE_INFINITY));
	}
	
	// EC13; Positive infinity value, NOM definite range
	@Test
	public void test22_valuePosInfinityforMethodContains() {
		exampleRange = new Range(-1 , Double.POSITIVE_INFINITY);
		assertTrue("The value Double.POSITIVE_INFINITY should be within "
				+ "-1 and Double.POSITIVE_INFINITY",
				exampleRange.contains(Double.POSITIVE_INFINITY));
	}
	
	// EC14; Invalid value (not a number), NOM definite range
	@Test
	public void test23_valueNotANumberforMethodContains() {
		exampleRange = new Range(-100, 100);
		assertFalse("The value Double.NaN should NOT be within "
				+ "-100 and 100",
				exampleRange.contains(Double.NaN));
	}
	// End testing method public boolean contains(double value)
	
	
	
	@After
	public void tearDown() throws Exception {
		exampleRange = null;
	}
	
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}
}