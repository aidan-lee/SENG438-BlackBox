package org.jfree.data.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.security.InvalidParameterException;

import org.junit.*;

import org.jfree.data.DataUtilities;
import org.junit.AfterClass;
import org.junit.Test;

/**
 * Testing method static java.lang.Number[] createNumberArray(double[] data)  
 * in class org.jfree.data.DataUtilities
 *
 */
public class DataUtilitiesCreateNumberArrayTest extends DataUtilities
{
	private double[] nullArray;
	private double[] emptyArray = new double[0];
	private double[] oneElementEmptyArray = new double[1];
	private double[] oneElementNonEmptyArray = {1.0};
	private double[] oneElementPosInfArray = {Double.POSITIVE_INFINITY};
	private double[] oneElementNegInfArray = {Double.NEGATIVE_INFINITY};
	private double[] oneElementNaNArray = {Double.NaN};
	private double[] oneElementNegArray = {-1.5};
	private double[] multiElementValidArray = {3.3, Double.MIN_VALUE, Double.MAX_VALUE, 0, Double.MAX_VALUE - 1, Double.MIN_VALUE + 1};
	//Boundary Value Testing/Weak Robustness testing
	//Variables:
	//Array Length (L):
	//0 <= L < ?, L != null, NaN
	//The length of an array must be between zero and an unknown number that is less than Double.MAX_VALUE and less than +infinity
	//Test Cases:
	//L = null - 
	//L < 0 - This is not testable, as you cannot initialize an array with negative length
	//L = 0 - L_LB
	//L = 1 - L_ALB
	//1 < L < ? - LNOM
	//L > ? - This is not testable, as we don't know what the max size of an array is (it's probably system dependent)
	//Values in the array (V):
	//-infinity < V < +infinity, V != null
	//V = Double,MIN_VALUE - 1 - Not testable. Double.MIN_VALUE - 1 = Double.MIN_VALUE due to rounding
	//V = Double.MIN_VALUE - V_LB
	//V = Double.MIN_VALUE + 1 - V_ALB
	//V < 0 - V_NOM
	//V = 0 - V_NOM
	//V > 0 - V_NOM
	//V = Double.MAX_VALUE - 1 - V_BUB
	//V = Double.MAX_VALUE - V_UB
	//V = Double.MAX_VALUE + 1 - Not testable. Double.MAX_VALUE + 1 = Double.MAX_VALUE due to rounding
	//V = Double.NEGATIVE_INFINITY
	//V = Double.POSITIVE_INFINITY
	//V = Double.NaN
	//V = null
	//Tests--------------------------------------------------------------------------------
	@Test//(expected = InvalidParameterException.class)
	public void test_CreateNumberArray_NullArray()
	{
		try
		{
			DataUtilities.createNumberArray(nullArray);
		}
		catch(InvalidParameterException e)
		{
			assertTrue(true);
		}
		catch(Exception e)
		{
			fail("createNumberArray did not throw an InvalidParameterException when given a null argument.");
		}
	}
	
	@Test
	public void test_CreateNumberArray_L_LB()
	{
		Number[] x = new Number[0];
		Assert.assertArrayEquals("createNumberArray did not create a 0 length array properly. (case L_LB)", x, DataUtilities.createNumberArray(emptyArray));
	}
	@Test
	public void test_CreateNumberArray_L_ALB_V_null()
	{
		Number[] x = new Number[1];
		Assert.assertArrayEquals("createNumberArray did not create a 1 length empty array properly. (case L_ALB, V_null)", x, DataUtilities.createNumberArray(oneElementEmptyArray));
	}
	@Test
	public void test_CreateNumberArray_L_ALB_V_NOMPOS()
	{
		Number[] x = {1.0};
		Assert.assertArrayEquals("createNumberArray did not create a 1 length v = 1 array properly. (case L_ALB, V_NOM)", x, DataUtilities.createNumberArray(oneElementNonEmptyArray));
	}
	@Test
	public void test_CreateNumberArray_L_ALB_V_POSINF()
	{
		Number[] x = {Double.POSITIVE_INFINITY};
		Assert.assertArrayEquals("createNumberArray did not create a 1 length v = +inf array properly. (case L_ALB, V_POSINF)", x, DataUtilities.createNumberArray(oneElementPosInfArray));
	}
	
	@Test
	public void test_CreateNumberArray_L_ALB_V_NEGINF()
	{
		Number[] x = {Double.NEGATIVE_INFINITY};
		Assert.assertArrayEquals("createNumberArray did not create a 1 length v = -inf array properly. (case L_ALB, V_NEGINF)", x, DataUtilities.createNumberArray(oneElementNegInfArray));
	}
	@Test
	public void test_CreateNumberArray_L_ALB_V_NAN()
	{
		Number[] x = {Double.NaN};
		Assert.assertArrayEquals("createNumberArray did not create a 1 length v = NaN array properly. (case L_ALB, V_NAN)", x, DataUtilities.createNumberArray(oneElementNaNArray));
	}
	@Test
	public void test_CreateNumberArray_L_ALB_V_NOMNEG()
	{
		Number[] x = {-1.5};
		Assert.assertArrayEquals("createNumberArray did not create a 1 length v = -1.5 array properly. (case L_ALB, V_NOM)", x, DataUtilities.createNumberArray(oneElementNegArray));
	}
	@Test
	public void test_CreateNumberArrayL_NOM_V_LB_V_ALB_V_NOM_V_BUB_V_UB()
	{
		Number[] x = {3.3, Double.MIN_VALUE, Double.MAX_VALUE, 0.0, Double.MAX_VALUE - 1, Double.MIN_VALUE + 1};
		Assert.assertArrayEquals("createNumberArray did not create a 6 length v = {3.3, Double.MIN_VALUE, Double.MAX_VALUE, 0.0, Double.MAX_VALUE - 1, Double.MIN_VALUE + 1} array properly. (case L_NOM, V_LB, V_ALB, V_NOM, V_BUB, V_UB)", x, DataUtilities.createNumberArray(multiElementValidArray));
	}
//--------------------------------------------------------------------------------------
}
